CREATE DATABASE pcloud2gdrive;

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username text NOT NULL,
  email text NOT NULL,
  password_digest text,
  pcloud_token TEXT,
  gdrive_token TEXT
);

CREATE TABLE "session" (
  "sid" varchar NOT NULL COLLATE "default",
  "sess" json NOT NULL,
  "expire" timestamp(6) NOT NULL
)
WITH (OIDS=FALSE);

ALTER TABLE "session" ADD CONSTRAINT "session_pkey" PRIMARY KEY ("sid") NOT DEFERRABLE INITIALLY IMMEDIATE;

CREATE INDEX "IDX_session_expire" ON "session" ("expire");

CREATE TABLE tasks (
  id SERIAL PRIMARY KEY,
  user_id TEXT,
  task_name TEXT,
  origin_folder TEXT,
  destination_folder TEXT
);